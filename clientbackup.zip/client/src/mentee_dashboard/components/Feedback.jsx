import React from "react";

const Feedback = () => {
  return (
    <div className="bg-[#E6CCE3] p-6 shadow-md rounded-lg">
      <h3 className="text-2xl font-semibold mb-4">Feedback</h3>
      {/* Feedback form */}
      <p>[Form for feedback here]</p>
    </div>
  );
};

export default Feedback;