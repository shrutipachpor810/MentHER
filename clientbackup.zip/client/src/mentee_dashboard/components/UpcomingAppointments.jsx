import React from "react";

const UpcomingAppointments = () => {
  return (
    <div className="bg-[#FCE1D8] p-6 shadow-md rounded-lg mt-4">
      <h3 className="text-2xl font-semibold mb-4">Upcoming & Past Appointments</h3>
      {/* Appointment cards */}
      <p>[List of appointments here]</p>
    </div>
  );
};

export default UpcomingAppointments;