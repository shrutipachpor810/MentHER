import React from "react";

const AppointmentBooking = () => {
  return (
    <div className="bg-white p-6 shadow-md rounded-lg">
      <h3 className="text-2xl font-semibold mb-4">Book Appointment</h3>
      {/* Form or Calendar component to book appointment */}
      <p>[Appointment booking form here]</p>
    </div>
  );
};

export default AppointmentBooking;