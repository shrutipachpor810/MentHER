import React from "react";

const TimeSlots = () => {
  return (
    <div className="bg-[#E2ECE9] p-6 shadow-md rounded-lg">
      <h3 className="text-2xl font-semibold mb-4">Available Time Slots</h3>
      {/* Slot selection logic */}
      <p>[Slots UI here]</p>
    </div>
  );
};

export default TimeSlots;