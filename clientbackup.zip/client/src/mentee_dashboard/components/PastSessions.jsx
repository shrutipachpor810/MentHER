const PastSessions = () => (
  <div>
    <p className="text-sm text-gray-600 mb-2">Review your past sessions and add notes if needed.</p>
    <div className="p-4 bg-gray-100 rounded">[Past sessions table here]</div>
  </div>
);
export default PastSessions;
